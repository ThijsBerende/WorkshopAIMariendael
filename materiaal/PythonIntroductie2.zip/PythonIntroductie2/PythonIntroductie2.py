"""
    Welkom bij het tweede deel van deze python introductie/herhaling van de programmeertaal Python.
    Deze opdrachten zijn bedoeld om er voor te zorgen dat je (weer) bekend raakt
    met de meeste gebruikte functies van Python

    Als je er niet uit komt, klaar bent, of andere vragen hebt, laat het ons weten
    Wij zullen zoveel mogelijk rondlopen en helpen!
"""

def for_loops_met_lijsten():
    """
        1.1 Met for loops kun je ook lijsten doorlopen, dit kan op meerdere manieren.
        Lijsten kun je gebruiken als range met len(lijst), dit geeft de lengte van de lijst.
        Maak maar eens een lijst en print de waarden met een for loop met range(0, len(lijst))
        1.2 Je kunt ook complexere operaties uitvoeren in een for loop.
        Maak een lijst genaamd cijfers met de cijfers 1 tot en met 10.
        Maak ook een for loop met range(0, len(cijfers))
        Lukt het jou om met je nieuwe kennis van if-else constructies alleen de getallen
        die voorkomen in de tafel van 2 te printen?
        1.3 Het is ook mogelijk om direct door de waardes van een lijst heen te lopen met een for loop.
        Dit kan met de constructie for item in lijst:
        Probeer dit maar eens met de lijst cijfers,
        wat denk je dat er zal gebeuren als je alleen print(item) aanroept in de for loop?
    """

def gelijke_waardes():
    """
        2.1 Wat denk je dat je terug krijgt als je print(1 == "1")? True, of False?
        2.2 Als het goed is heb je gezien of geraden dat dit False is. Maar wat als je Een nummer in een string krijgt?
        Als je er dan mee wilt rekenen moet je de waarde eerst 'casten' naar het type int.
        Probeer maar eens, print(1 == int("1"))
        2.3 Wat denk je dat er gebeurt als je een string met letters cast naar een int?
        Probeer het eens.
    """

def voer_functies_uit():
    for_loops_met_lijsten()
    gelijke_waardes()

if __name__ == '__main__':
    voer_functies_uit()